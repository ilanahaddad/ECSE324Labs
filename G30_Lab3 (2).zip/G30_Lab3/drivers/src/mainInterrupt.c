#include <stdio.h>
#include "../../drivers/inc/int_setup.h"
#include "../../drivers/inc/ISRs.h"
#include "../../drivers/inc/HEX_displays.h"
#include "../../drivers/inc/HPS_TIM.h"
#include "../../drivers/inc/pushbuttons.h"
/*
int main(){
	//Enable interupts for push buttons and hps timer 0
	int_setup(2, (int []) {73, 199});

	//Enable interrupts for pushbuttons
	enable_PB_INT_ASM(PB0 | PB1 | PB2);	

	//Initialize timer parameters
	HPS_TIM_config_t t0;
	t0.tim = TIM0;
	t0.timeout = 10000;	//10ms
	t0.LD_en = 1;
	t0.INT_en = 0;
	t0.enable = 1;
	HPS_TIM_config_ASM(&t0);

	int ms = 0;
	int sec = 0;
	int min = 0;
//	int timer = 0; 
	pb_int_flag = 4; 	//without this, timer starts automatically
	while(1) {
		//Check if interrupt for pushbuttons occurs
		if (pb_int_flag >=0) { 
			//if the interrupt is button 0: start timer
			if (pb_int_flag == 0) { 
				t0.LD_en = 1;
				t0.INT_en = 1;
				t0.enable = 1;
				HPS_TIM_config_ASM(&t0);
				pb_int_flag = 4 ;	//Reset the interrupt flag 
			} 
			//if the interrupt is button 1: stop timer
			else if (pb_int_flag == 1) {
				t0.LD_en = 0;
				t0.INT_en = 0;
				t0.enable = 0;
				HPS_TIM_config_ASM(&t0);
				pb_int_flag = 4 ;	//Reset the interrupt flag 			
			} 
			//if the interrupt is button 2: reset and stop the timer
			else if (pb_int_flag == 2) { 
				t0.LD_en = 0;
				t0.INT_en = 0;
				t0.enable = 0;
				HPS_TIM_config_ASM(&t0);
				if(HPS_TIM_read_INT_ASM(t0.tim) == 0){
					HEX_flood_ASM(HEX0|HEX1|HEX2|HEX3|HEX4|HEX5);		
				}
				ms = 0;
				sec = 0;
				min = 0;
				HEX_write_ASM(HEX0 | HEX1 | HEX2 | HEX3 | HEX4 | HEX5, 0); //rewrites all hex values to 0
				pb_int_flag = 4 ;//Reset the interrupt flag 
			}
		}
		if(hps_tim0_int_flag){
			hps_tim0_int_flag = 0;
			ms = ms +10; //timer is for 10 milliseconds
			//ensure ms, sec, and min are within thei ranges:
			if(ms >= 1000){
				ms = ms - 1000; 
				sec++; //increment seconds
				if(sec >= 60){
					sec = sec - 60;
					min++; //increment minutes
					if(min >= 60){
						min = 0;
					}
				}
			}

			//write times to the appropriate hex displays
			HEX_write_ASM(HEX0, ((ms % 100) / 10));
			HEX_write_ASM(HEX1, (ms / 100));
			HEX_write_ASM(HEX2, (sec % 10));
			HEX_write_ASM(HEX3, (sec / 10));
			HEX_write_ASM(HEX4, (min % 10));
			HEX_write_ASM(HEX5, (min / 10));
		}
	} 
	return 0;
}
*/