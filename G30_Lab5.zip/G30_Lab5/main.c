#include <math.h>

#include "./drivers/inc/vga.h"
#include "./drivers/inc/ISRs.h"
#include "./drivers/inc/LEDs.h"
#include "./drivers/inc/audio.h"
#include "./drivers/inc/HPS_TIM.h"
#include "./drivers/inc/int_setup.h"
#include "./drivers/inc/wavetable.h"
#include "./drivers/inc/pushbuttons.h"
#include "./drivers/inc/ps2_keyboard.h"
#include "./drivers/inc/HEX_displays.h"
#include "./drivers/inc/slider_switches.h"

//Function Declerations:
float mod_float(float x, float y); 
int signal(float f, int t);

//Global variables declerations:
int amplitude = 1; //volume originally set to 1, can be changed later 
float key_pressed[8] = {0, 0, 0, 0, 0, 0, 0, 0 };
float frequencies[8] = {130.813, 146.832, 164.814, 174.614, 195.998, 220.000, 246.942, 261.626}; //array for frequencies

int main() {

	while(1) {
		//	MAKE PROJECT!
	}

	return 0;
}

//Function that calculaes the modulo of two floats, x%y
float mod_float(float x, float y){
	int integer_division = (int)x/y;
	float result = x - (integer_division*y);
}
//Function that generates a signal for a given frequency f and sampling insant t
int signal(float f, int t){
	//index = (f*t)%48000
	float index = mod_float(f*t, 48000);

	//linear interpolation if index is not an integer:
		//table[10.73] := (1-0.73)*table[10] + 0.73*table[11]
	int index_int = (int) index; //integer value of index
	float index_decimal = index - index_cast; //decimal value of index
		//table[index] := (1-index_decimal)*table[index_int] + index_decimal*table[index_int + 1]
	float interpolation = (1-index_decimal)*(sine[index_int]) + (index_decimal)*(sine[index_int+1]);

	//signal = amplitude * table[index]
	int signal = (int) (amplitude*(sine[index]));
	return signal;
}
//Function that calculates the total frequency when a certain keyboard key is pressed
float calculateFreq(char* data){
	//Key pressed = '+' : volume up => amplitude++
	if(*data == 0x79){
		if(*previous != 0x70){//only if not a break code
			amplitude++;
		}
	}
	//key pressed = '-' : volume down => amplitude--
	else if(*data == 0x7B){
		if(*previous != 0xF0){//only if not a break code
			if(amplitude != 0){ //decrease amplitude unless its already at 0 
				amplitude--;
			}
		}
	}
	//key pressed = 'A' : note C
	else if(*data == 0x1C){
		if(*previous != 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[0] = 0;
		}
		else{ //if it's not a breakcode then set it to true
			key_pressed[0] = 1;
		}
	}
	//key pressed = 'S' : note D
	else if(*data == 0x1B){
		if(*previous != 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[1] = 0;
		}
		else{
			key_pressed[1] = 1;
		}
	}
	//key pressed = 'D' : note E
	else if(*data == 0x23){
		if(*previous != 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[2] = 0;
		}
		else{
			key_pressed[2] = 1;
		}
	}
	//key pressed = 'F' : note F
	else if(*data == 0x2B){
		if(*previous != 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[3] = 0;
		}
		else{
			key_pressed[3] = 1;
		}
	}
	//key pressed = 'J' : note G
	else if(*data == 0x3B){
		if(*previous != 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[4] = 0;
		}
		else{
			key_pressed[4] = 1;
		}
	}
	//key pressed = 'K' : note A
	else if(*data == 0x42){
		if(*previous != 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[5] = 0;
		}
		else{
			key_pressed[5] = 1;
		}
	}
	//key pressed = 'L' : note B
	else if(*data == 0x4B){
		if(*previous != 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[6] = 0;
		}
		else{
			key_pressed[6] = 1;
		}
	}
	//key pressed = ';' : note C
	else if(*data == 0x4C){
		if(*previous != 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[7] = 0;
		}
		else{
			key_pressed[7] = 1;
		}
	}

	//TODO: COMPUTER TOTAL FREQUENCY


}









