#ifndef __LEDS
#define __LEDS
	
	extern int read_LEDs_ASM();
	extern void write_LEDs_ASM(int LEDs);

#endif



