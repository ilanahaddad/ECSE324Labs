#ifndef __LEDs
#define __LEDs

	extern int read_LEDs_ASM();
	extern int write_LEDs_ASM(int value);

#endif