#ifndef _INT_SETUP
#define _INT_SETUP

	#include "../../drivers/inc/address_map_arm.h"
	#include "../../drivers/inc/ISRs.h"

	void disable_A9_interrupts();
	void enable_A9_interrupts();
	void int_setup(int len, int* IDs);
	
#endif
