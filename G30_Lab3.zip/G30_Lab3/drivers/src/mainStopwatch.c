#include <stdio.h>
#include "../../drivers/inc/HEX_displays.h"
#include "../../drivers/inc/HPS_TIM.h"
#include "../../drivers/inc/pushbuttons.h"

/*
int main(){
	//first timer for stopwatch 
	HPS_TIM_config_t t0;
	t0.tim = TIM0;
	t0.timeout = 10000;	//10ms
	t0.LD_en = 0;
	t0.INT_en = 0;
	t0.enable = 0;
	HPS_TIM_config_ASM(&t0);

	//second timer used for polling 
	HPS_TIM_config_t poll;
	poll.tim = TIM1;
	poll.timeout = 5000;	// 5 milisecond polling delay
	poll.LD_en = 1;
	poll.INT_en = 1;
	poll.enable = 1;
	HPS_TIM_config_ASM(&poll);
	int pollCount = 0;

	// stopwatch variables
	int ms = 0;
	int sec = 0;
	int min = 0;


//PB_clear_edgecp_ASM
	while(1){
		if(HPS_TIM_read_INT_ASM(poll.tim)){
			HPS_TIM_clear_INT_ASM(poll.tim);
				int button = read_PB_edgecap_ASM();
				if(button >=1){
					if(PB_edgecap_is_pressed_ASM(PB0)){
						t0.LD_en = 1;
						t0.INT_en = 1;
						t0.enable = 1;
						HPS_TIM_config_ASM(&t0);
					}
					if(PB_edgecap_is_pressed_ASM(PB2)){
						t0.LD_en = 0;
						t0.INT_en = 0;
						t0.enable = 0;
						HPS_TIM_config_ASM(&t0);
						if(HPS_TIM_read_INT_ASM(t0.tim) == 0){
							HEX_flood_ASM(HEX0|HEX1|HEX2|HEX3|HEX4|HEX5);	// not quite sure what this does?			
						}
						ms = 0;
						sec = 0;
						min = 0;
						HEX_write_ASM(HEX0 | HEX1 | HEX2 | HEX3 | HEX4 | HEX5, 0); //rewrites all hex values to 0
					}

					if(PB_edgecap_is_pressed_ASM(PB1)){
						t0.LD_en = 0;
						t0.INT_en = 0;
						t0.enable = 0;
						HPS_TIM_config_ASM(&t0);
					}
					PB_clear_edgecp_ASM(15);
				}
			}
				if(HPS_TIM_read_INT_ASM(t0.tim)){
					HPS_TIM_clear_INT_ASM(t0.tim);
					ms = ms +10; //timer is for 10 milliseconds
					//ensure ms, sec, and min are within thei ranges:
					if(ms >= 1000){
						ms = ms - 1000; 
						sec++; //increment seconds

					if(sec >= 60){
						sec = sec - 60;
						min++; //increment minutes
					if(min >= 60){
						min = 0;
					}
				}
			}

				//write times to the appropriate hex displays
				HEX_write_ASM(HEX0, ((ms % 100) / 10));
				HEX_write_ASM(HEX1, (ms / 100));
				HEX_write_ASM(HEX2, (sec % 10));
				HEX_write_ASM(HEX3, (sec / 10));
				HEX_write_ASM(HEX4, (min % 10));
				HEX_write_ASM(HEX5, (min / 10));
				}
			}
	return 0;
}
*/
