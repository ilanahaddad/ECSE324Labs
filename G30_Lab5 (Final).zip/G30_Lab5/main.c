
#include "./drivers/inc/vga.h"
#include "./drivers/inc/ISRs.h"
#include "./drivers/inc/LEDs.h"
#include "./drivers/inc/audio.h"
#include "./drivers/inc/HPS_TIM.h"
#include "./drivers/inc/int_setup.h"
#include "./drivers/inc/wavetable.h"
#include "./drivers/inc/pushbuttons.h"
#include "./drivers/inc/ps2_keyboard.h"
#include "./drivers/inc/HEX_displays.h"
#include "./drivers/inc/slider_switches.h"

//Function Declerations:
float mod_float(float x, float y); 
int signal(float f, int t);
float calculateFreq(char *data);
void drawWave(float freq);

//Global variables declerations:
int amplitude = 1; //volume originally set to 1, can be changed later 
float key_pressed[8] = {0, 0, 0, 0, 0, 0, 0, 0 };
float frequencies[8] = {130.813, 146.832, 164.814, 174.614, 195.998, 220.000, 246.942, 261.626}; //array for frequencies
char *previous; //previous keyboard code

int main() {
	//interrupts for tim0
	int_setup(1, (int[]){199});

	//intializing the timer tim0
	HPS_TIM_config_t hps_tim;
	hps_tim.tim = TIM0;
	hps_tim.timeout = 20.8; // 1/48000 = 20.8 microseconds => round up to 21
	hps_tim.LD_en = 1; 
	hps_tim.INT_en = 1; //enable interupt
	hps_tim.enable = 1;	// enable bit to 1

	//setup configuration of timer we just initialized
	HPS_TIM_config_ASM(&hps_tim);

	char *data; //data received from the keyboard
	float freq;	//frequency of note played
	int clock =0;	//clock cycle 0

	while(1) {
		if(read_ps2_data_ASM(data)){ //if keyboard key is pressed, the data is stored in the pointer and subroutine returns 1 (true)
			if(*previous != *data){ //to avoid recalculating the same frequency if same key is pressed
				//get frequency from keys being pressed:
				freq = calculateFreq(data);
				//draw wave on display
				drawWave(freq);
				if(*previous == 0xF0){ // this allows to press the same key right away after letting go
					*previous = 0;
				}
				else{ //otherwise set the code to the previous code
					*previous = *data;
				}
			}
		}	

		audio_write_data_ASM(signal(freq,clock), signal(freq,clock));
		if(hps_tim0_int_flag){ //if there has been an interupt
			clock++; //incremenet the clock
			if(clock > (int)(48000/freq)){
				clock = 0; //reset clock if we've reached end of period
				hps_tim0_int_flag = 0; //reset flag variable to 0
			}
		}
	}

	return 0;
}

//Function that calculaes the modulo of two floats, x%y
float mod_float(float x, float y){
	int integer_division = (int)x/y;
	float result = x - (integer_division*y);
	return result;
}

//Function that generates a signal for a given frequency f and sampling insant t
int signal(float f, int t){
	//index = (f*t)%48000
	float index = mod_float(f*t, 48000);

	//linear interpolation if index is not an integer:
		//table[10.73] := (1-0.73)*table[10] + 0.73*table[11]
	int index_int = (int) index; //integer value of index
	float index_decimal = index - index_int; //decimal value of index
		//table[index] := (1-index_decimal)*table[index_int] + index_decimal*table[index_int + 1]
	float interpolation = (1-index_decimal)*(sine[index_int]) + (index_decimal)*(sine[index_int+1]);

	//signal = amplitude * table[index]
	int signal_result = (int) (amplitude*interpolation);
	return signal_result;
}
//Function that calculates the total frequency when a certain keyboard key is pressed
float calculateFreq(char* data){
	//Key pressed = '+' : volume up => amplitude++
	if(*data == 0x55){
		if(*previous != 0xF0){//only if not a break code
			amplitude++;
		}
	}
	//key pressed = '-' : volume down => amplitude--
	else if(*data == 0x4E){
		if(*previous != 0xF0){//only if not a break code
			if(amplitude != 0){ //decrease amplitude unless its already at 0 
				amplitude--;
			}
		}
	}
	//key pressed = 'A' : note C
	else if(*data == 0x1C){
		if(*previous == 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[0] = 0;
		}
		else{ //if it's not a breakcode then set it to true
			key_pressed[0] = 1;
		}
	}
	//key pressed = 'S' : note D
	else if(*data == 0x1B){
		if(*previous == 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[1] = 0;
		}
		else{
			key_pressed[1] = 1;
		}
	}
	//key pressed = 'D' : note E
	else if(*data == 0x23){
		if(*previous == 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[2] = 0;
		}
		else{
			key_pressed[2] = 1;
		}
	}
	//key pressed = 'F' : note F
	else if(*data == 0x2B){
		if(*previous == 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[3] = 0;
		}
		else{
			key_pressed[3] = 1;
		}
	}
	//key pressed = 'J' : note G
	else if(*data == 0x3B){
		if(*previous == 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[4] = 0;
		}
		else{
			key_pressed[4] = 1;
		}
	}
	//key pressed = 'K' : note A
	else if(*data == 0x42){
		if(*previous == 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[5] = 0;
		}
		else{
			key_pressed[5] = 1;
		}
	}
	//key pressed = 'L' : note B
	else if(*data == 0x4B){
		if(*previous == 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[6] = 0;
		}
		else{
			key_pressed[6] = 1;
		}
	}
	//key pressed = ';' : note C
	else if(*data == 0x4C){
		if(*previous == 0xF0){//if it is a breakcode, set boolean of key_pressed to false
			key_pressed[7] = 0;
		}
		else{
			key_pressed[7] = 1;
		}
	}
	float total_frequency;
	int i;
	//compute total frequency
	for(i =0; i< 8 ;i++){
		total_frequency += key_pressed[i]*frequencies[i];
	}

	return total_frequency;
}
void drawWave(float freq){
	VGA_clear_pixelbuff_ASM(); //clear display
	int x,y;	//position on screen display
	short colour = 0xFFFFFF; //white
	
	int increment = 48000/( (320.00/freq)*60 );
	int x_pos = 0;
	
	for(x=0; x<= 319; x++){
		float temp = (float) sine[x_pos] * ( (float) 10/ (float) sine[6000]);
		y = (int) ( (float)amplitude * temp ) + 120;
		VGA_draw_point_ASM(x,y,colour);
		
		x_pos += increment;
		if(x_pos>48000){
			x_pos = x_pos - 48000;
		}
	}
	
}








