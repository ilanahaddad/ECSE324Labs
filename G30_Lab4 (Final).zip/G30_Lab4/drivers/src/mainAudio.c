#include <stdio.h>
#include "../../drivers/inc/VGA.h"
#include "../../drivers/inc/pushbuttons.h"
#include "../../drivers/inc/slider_switches.h"
#include "../../drivers/inc/audio.h"

int main() {
	int samples = 0;
	int signal = 0x000FFFFF;	//when the signal is 1
	while(1) {
		if (play_audio_ASM(signal)) { //if  board is receiving signal"
			samples++;	//increase counter for samples
			if (samples > 239) {	//if sample reaches 240, reset the counter
				samples = 0;
				if (signal == 0x00000000) {	//if signal is 0, change it to 1 (in hex)
					signal = 0x00FFFFFF;
				} 
				else { //if the signal is 1, change it to 0
					signal =  0x00000000;
				}
			}
		}
	} return 0;
}
//48k samples/sec
//we want frequency 100Hz = 100 cycles/sec
//48000 samples/100cycles = 480 samples/cycle
//for samples 0 to 239: signal = 1
//for samples > 239: toggle
