#include <stdio.h>
#include "../../drivers/inc/VGA.h"
#include "../../drivers/inc/ps2_keyboard.h"
/*
// The application should read raw data from the keyboard and display it to the screen if it is valid.
//Only the VGA_write_byte_ASM subroutine is needed from the VGA driver, and the input byte is simply the data read from the keyboard
void main(){
	int x = 0;
	int y = 0;
	char *data ;
	VGA_clear_charbuff_ASM();
// Write 1st byte at (0,0), 2nd byte at (3,0), and so on until the 1st line on the screen is full.
//	Then, start writing bytes at (0,1), (3,1), (5,1), etc.
//	A gap of 3 x co-ordinates is given since each byte will display two characters, and one more for space between each byte
	while(1){
		if(read_PS2_data_ASM(data)){ //if the keyboard data have been read and stored in pointer, subroutine returns 1 and this will be true
			if(*data != 0){ //double check data isnt 0
				VGA_write_byte_ASM(x, y, *data); //write 1st byte at (0,0)
				x+=3; //next byte must be written at (3,0) and so on 
				if(x > 79){//once 1st line on the screen is full:
					x = 0;	//reset x to 0
					y += 1;	//increment y
				}//end of x
				if(y > 59){ //once y position has reached the end of the screen, reset both x and y and clear the screen
					x = 0;
					y = 0; 
					VGA_clear_charbuff_ASM();
				}//end of y
			}
			
		}
	}//end while
}
*/