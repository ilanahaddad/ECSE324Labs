#ifndef __AUDIO
#define __AUDIO

	extern int play_audio_ASM(int data);

#endif
