#ifndef __PS2_KEYBOARD
#define __PS2_KEYBOARD
	/*This subroutine will check the RVALID bit in the PS/2 Data register.
		If it is valid, then the data from the same register should be stored at the
		address in the char pointer argument, and the subroutine should return 1 to denote valid data.
		If the RVALID bit is not set, then the subroutine should simply return 0 */
	extern int read_PS2_data_ASM(char *data);

#endif