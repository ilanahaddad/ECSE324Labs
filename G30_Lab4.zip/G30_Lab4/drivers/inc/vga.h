#ifndef __VGA
#define __VGA
	/* These subroutines should clear (set to 0) all the valid memory locations 
		in the character buffer and pixel buffer respectively*/
	void VGA_clear_charbuff_ASM();
	void VGA_clear_pixelbuff_ASM();

	/* This subroutine should write ASCII code passed in the 3rd argument to the screen at
		coordinates (x,y), given in the first 2 arguments. The subroutine should check that the coordinates
		supplied are valid (x = [0,79], y = [0,59])*/
	void VGA_write_char_ASM(int x, int y, char c);

	/* This subroutine should write the hexadecimal representation of the value passed in the 3rd argument
		onto the screen. This means that the subroutine will print two characters on the screen
		For example, passing value 0xFF in byte should reuslt in the characters 'FF' being displayed on the screen
		starting at the x,y coordinates passed in the first 2 arguments. Again, check that x and y coordinates are valid,
		taking into account that two characters will be displayed*/
	void VGA_write_byte_ASM(int x, int y,	char byte);
	
	/* This subroutine will draw a point on the screen with the colour as indicated in the 3rd argument,
		by accessing only the pixel buffer memory*/
	void VGA_draw_point_ASM(int x, int y, short colour);

#endif
