#include <stdio.h>
#include "../../drivers/inc/VGA.h"
#include "../../drivers/inc/pushbuttons.h"
#include "../../drivers/inc/slider_switches.h"
/*
//function declarations:
void test_char();
void test_byte();
void test_pixel();

void main(){
	while(1){
		//PB0 is pressed: if any slider switches is on, call test_byte(), otherwise, call test_char()
		if(PB_edgecap_is_pressed_ASM(PB0)){
			if(read_slider_switches_ASM() != 0){
				test_byte();
			}
			else{
				test_char();
			}	
		} 
		//PB1 is pressed: call test_pixel
		if(PB_edgecap_is_pressed_ASM(PB1)){
			test_pixel();
		}
		//PB2 is pressed: clear the character buffer
		if(PB_edgecap_is_pressed_ASM(PB2)){
			VGA_clear_charbuff_ASM();
		}
		//PB3 is pressed: clear the pixel buffer
		if(PB_edgecap_is_pressed_ASM(PB3)){
			VGA_clear_pixelbuff_ASM();
		}

	} //end while
}//end main
void test_char(){
	int x,y;
	char c =0;
	
	for(y=0; y<=59; y++){
		for(x=0; x<= 79; x++){
			VGA_write_char_ASM(x,y, c++);
		}
	}
}//end of test_char

void test_byte(){
	int x,y;
	char c =0;
	
	for(y=0; y<=59; y++){
		for(x=0; x<= 79; x+=3){
			VGA_write_byte_ASM(x,y, c++);
		}
	}
}//end of test_byte

void test_pixel(){
	int x,y;
	unsigned short colour =0;
	
	for(y=0; y<=239; y++){
		for(x=0; x<= 319; x++){
			VGA_draw_point_ASM(x,y, colour++);
		}
	}
}//end of test_pixel

*/
